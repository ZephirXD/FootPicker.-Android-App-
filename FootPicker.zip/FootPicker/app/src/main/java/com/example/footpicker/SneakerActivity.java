package com.example.footpicker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class SneakerActivity extends AppCompatActivity {
    Spinner sizesSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sneaker);
        sizesSpinner = findViewById(R.id.spinner);
        ArrayList<Integer> sizes = new ArrayList<>();
        sizes.add(39);
        sizes.add(40);
        sizes.add(41);
        sizes.add(42);
        sizes.add(43);
        sizes.add(44);
        ArrayAdapter<Integer> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sizes);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sizesSpinner.setAdapter(spinnerAdapter);
    }

    public void addToCard(View view) {
        order newOrder = new order();
        newOrder.Size = sizesSpinner.getSelectedItem().toString();
        newOrder.sneakersModel = "Nike Air Force 1 Low";
        newOrder.price = 75;

        Intent orderIntent = new Intent(this, OrderActivity.class);
        orderIntent.putExtra("size", newOrder.Size);
        orderIntent.putExtra("sneakersModel", newOrder.sneakersModel);
        orderIntent.putExtra("price", newOrder.price);
        startActivity(orderIntent);
    }
}
