package com.example.footpicker;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import android.preference.PreferenceManager;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
public class OrderActivity extends AppCompatActivity {
    private LinearLayout parentLayout;
    private TextView totalPrice;
    private SharedPreferences sharedPreferences;
    private String size;
    private int price;
    private String sneakersModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        Intent intent = getIntent();
        size = intent.getStringExtra("size");
        price = intent.getIntExtra("price",0);
        sneakersModel = intent.getStringExtra("sneakersModel");
        parentLayout = findViewById(R.id.parent_layout);
        totalPrice = findViewById(R.id.TotalPrice);


        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        restoreOrderState(size);
        addNewItem(size);
    }
    @Override
    protected void onStop() {
        super.onStop();
        saveOrderState();
    }
    private void saveOrderState() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("item_count", parentLayout.getChildCount());
        editor.apply();
    }
    private void restoreOrderState(String size) {
        int itemCount = sharedPreferences.getInt("item_count", 0);
        parentLayout.removeAllViews();
        for (int i = 0; i < itemCount; i++) {
            addNewItem(size);
        }
        totalPrice.setText("Total price = $" + itemCount*price);

    }
    private void addNewItem(final String size) {
        final LinearLayout newLinearLayout = new LinearLayout(this);
        newLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        newLinearLayout.setOrientation(LinearLayout.HORIZONTAL);


        ImageView imageView = new ImageView(this);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(
                199,
                150));
        imageView.setImageResource(R.drawable.air_force_1_low_07_triple_white_348189);
        newLinearLayout.addView(imageView);

        LinearLayout secondLinearLayout = new LinearLayout(this);
        secondLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1));
        secondLinearLayout.setOrientation(LinearLayout.VERTICAL);

        TextView nameTextView = new TextView(this);
        nameTextView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                0,
                1));
        nameTextView.setText(sneakersModel);
        nameTextView.setTextSize(20);
        secondLinearLayout.addView(nameTextView);

        LinearLayout buttonsLinearLayout = new LinearLayout(this);
        buttonsLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        buttonsLinearLayout.setOrientation(LinearLayout.HORIZONTAL);

        Button deleteButton = new Button(this);
        deleteButton.setLayoutParams(new LinearLayout.LayoutParams(
                350,
                130));
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                parentLayout.removeView(newLinearLayout);
            }
        });
        buttonsLinearLayout.addView(deleteButton);

        secondLinearLayout.addView(buttonsLinearLayout);

        TextView sizeTextView = new TextView(this);
        sizeTextView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        sizeTextView.setText("Size: " + size);
        secondLinearLayout.addView(sizeTextView);

        newLinearLayout.addView(secondLinearLayout);

        parentLayout.addView(newLinearLayout);
    }
}
